Clazz.declarePackage ("J.adapter.readers.cif");
Clazz.declareInterface (J.adapter.readers.cif, "MagCifRdrInterface");
