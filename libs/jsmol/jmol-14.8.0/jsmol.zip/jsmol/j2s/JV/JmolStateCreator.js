Clazz.declarePackage ("JV");
c$ = Clazz.declareType (JV, "JmolStateCreator");
